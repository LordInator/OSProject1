#include <stdio.h>
#include <stdbool.h>

#define VERBOSE 0

void printVerbose(const char *str);

int min(int a, int b);
int min3(int a, int b, int c);
